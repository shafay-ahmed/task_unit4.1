using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BumperSphereController : MonoBehaviour
{
    public int kills = 0;
    public float sizeIncreaseFactor = 0.1f; 
    public Material[] textures; 
    public float moveSpeed = 5.0f; 
    public float attractionForce = 2.0f; 

    private Renderer sphereRenderer;
    private Transform mainBall; 

    void Start()
    {
        sphereRenderer = GetComponent <Renderer>();
        ChangeTexture(); 

        
        mainBall = GameObject.FindGameObjectWithTag("MainBall").transform;
    }

    void Update()
    {
        
        Vector3 attractionDirection = (mainBall.position - transform.position).normalized;

        
        GetComponent<Rigidbody>().AddForce(attractionDirection * attractionForce);
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");


        Vector3 movement = new Vector3(horizontalInput, 0, verticalInput);
        transform.Translate(movement * moveSpeed * Time.deltaTime);
    }

    void OnCollisionEnter(Collision collision)
    {
       
        if (collision.gameObject.CompareTag("BumperSphere"))
        {
            
            kills++;
            float newSize = transform.localScale.x + sizeIncreaseFactor;
            transform.localScale = new Vector3(newSize, newSize, newSize);

            
            ChangeTexture();
        }
    }

    void ChangeTexture()
    {
        
        if (kills < textures.Length)
        {
            sphereRenderer.material = textures[kills];
        }
    }
}
