using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MultiFocusCamera : MonoBehaviour
{
    public Transform[] players; 

    void Update()
    {
        if (players.Length == 0)
        {
            return;
        }

        
        Bounds bounds = new Bounds(players[0].position, Vector3.zero);
        foreach (Transform player in players)
        {
            bounds.Encapsulate(player.position);
        }

        
        transform.position = new Vector3(bounds.center.x, transform.position.y, bounds.center.z);
        transform.LookAt(bounds.center);
    }
}
